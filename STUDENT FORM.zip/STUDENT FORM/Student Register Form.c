<!DOCTYPE html>
<html lang="en">
<head>
     <link rel="stylesheet" href="./bootstrap/bootstrap.min.css">
</head>
<body>
  <div class="from-group">
     <form class="m-3">
            <h1 class="text-center"> Student Register Form</h1>
            <label>Full Name:</label>
            <input type="text" class="form-control" placeholder="Enter your name">
          </div>

          <div class="from-group m-3">
            <label>Phone Number:</label>
            <input type="text" id="Enter Your Number" class="form-control" placeholder="Enter Your Number">
          </div>

            <div class="from-group m-3">
              <label>Date Of Birth:</label>
             <input type="date" id="DATE OF BIRTH" class="form-control" placeholder="dd-mm-yyyy">
          </div>

          <div class="from-group m-3">
            <label>Gender:</label> <br>
            <input type="radio" name="Male" id="Male" value="Male">
            <label>Male</label> 
            <input type="radio" name="female" value="Female">
            <label for="Female">Female</label>
            <input type="radio" name="female" value="">
            <label for="Prefer not to say">Prefer not to say</label>
          </div>

          <div class="from-group m-3">
            <label for="address">Address:</label>
            <input type="text" value="Enter street address" class="form-control" placeholder="Enter Street Address">
          </div>

          <div class="from-group m-3">
            <label for="country">Country:</label> 
            <select name="country" id="country" class="form-control">
              <option value="India">India</option>
              <option value="Austrila">Austrila</option>
              <option value="usa">USA</option>
            </select>
          </div>

           <div class="from-group m-3">
            <input type="enter u r city" value="Enter Your City" class="form-control">
          </div>

               <div class="from-group m-3">
                <input type="button btn btn-primary" value="Submit"  class="form-control btn btn-primary">
               </div>

            </form>
         

</body>
</html>